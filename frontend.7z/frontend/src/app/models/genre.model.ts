export interface Genre {
    id: string;
    title: string;
}