export interface ManyToManyUpdate {
    entityId: string;
    added: string[];
    removed: string[];
}