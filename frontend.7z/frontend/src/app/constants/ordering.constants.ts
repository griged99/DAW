export enum BookOrder {
    UPLOAD_TIME_ASCENDING = 1,
    UPLOAD_TIME_DESCENDING = 2
}