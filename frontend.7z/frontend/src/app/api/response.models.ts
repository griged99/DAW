export interface AuthenticationResponse {
    token: string;
}