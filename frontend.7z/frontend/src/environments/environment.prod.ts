export const environment = {
  production: true,
  serverPageSize: 6,
  clientPageSize: 3,
  apiUrl: 'https://ng-reading.azurewebsites.net/api'
};
